#!/usr/bin/env python3
"""
Generates every resource of the Industria mod: pixel-art textures (16x16, Minecraft style),
GUI texture, block/item models, blockstates, crafting recipes and lang files.

Usage:
    python3 tools/generate_assets.py                          # draws its own stone base for ores
    python3 tools/generate_assets.py --stone path/stone.png   # use the vanilla 16x16 stone.png as ore base

Requires: Pillow  (pip install pillow)
"""
import argparse
import json
import os
import random

from PIL import Image

MODID = "industria"
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.normpath(os.path.join(HERE, "..", "src", "main", "resources"))
ASSETS = os.path.join(RES, "assets", MODID)


# ----------------------------------------------------------------------------- io helpers
def _path(*parts):
    p = os.path.join(ASSETS, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def save_png(img, *parts):
    img.save(_path(*parts))


def save_json(obj, *parts):
    with open(_path(*parts), "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


def save_text(text, *parts):
    with open(_path(*parts), "w", encoding="utf-8") as fh:
        fh.write(text)


def rgba(c):
    return tuple(c) if len(c) == 4 else tuple(c) + (255,)


def new_img(w=16, h=16):
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))


def put(px, w, h, x, y, c):
    if 0 <= x < w and 0 <= y < h:
        px[x, y] = rgba(c)


# ----------------------------------------------------------------------------- palettes
# L = light, M = main, D = dark, O = outline
METALS = {
    "copper": dict(L=(255, 178, 120), M=(214, 124, 66), D=(148, 76, 40), O=(78, 38, 20)),
    "tin": dict(L=(244, 250, 252), M=(192, 207, 217), D=(128, 144, 158), O=(58, 68, 82)),
}
DUSTS = {
    "copper": dict(L=(240, 160, 100), M=(214, 124, 66), D=(160, 84, 44)),
    "tin": dict(L=(232, 240, 245), M=(192, 207, 217), D=(140, 156, 170)),
    "iron": dict(L=(228, 224, 220), M=(190, 186, 184), D=(134, 130, 130)),
    "gold": dict(L=(255, 246, 150), M=(250, 214, 60), D=(204, 152, 24)),
}


# ----------------------------------------------------------------------------- ores
def stone_base(stone_path=None):
    if stone_path:
        img = Image.open(stone_path).convert("RGBA")
        if img.size != (16, 16):
            img = img.crop((0, 0, 16, 16))
        return img
    rnd = random.Random(1337)
    img = new_img()
    px = img.load()
    tones = [(125, 125, 125), (118, 118, 118), (132, 132, 132), (110, 110, 110), (140, 140, 140), (121, 121, 121)]
    weights = [6, 3, 3, 1, 1, 3]
    for y in range(16):
        for x in range(16):
            px[x, y] = rgba(rnd.choices(tones, weights)[0])
    # darker speckle clusters like vanilla stone
    for _ in range(7):
        cx, cy = rnd.randrange(16), rnd.randrange(16)
        for dx, dy in [(0, 0), (1, 0), (0, 1)]:
            if rnd.random() < 0.8:
                put(px, 16, 16, (cx + dx) % 16, (cy + dy) % 16, (104, 104, 104))
    return img


ORE_CLUSTERS = [
    ((2, 2), [(0, 0), (1, 0), (0, 1), (1, 1), (2, 1), (1, 2)]),
    ((9, 1), [(0, 0), (1, 0), (2, 0), (1, 1), (2, 1)]),
    ((3, 9), [(0, 0), (1, 0), (0, 1), (1, 1)]),
    ((9, 8), [(0, 0), (1, 0), (1, 1), (2, 1), (2, 2)]),
    ((12, 13), [(0, 0), (1, 0)]),
]


def make_ore(stone, pal):
    img = stone.copy()
    px = img.load()
    for (ox, oy), cells in ORE_CLUSTERS:
        cellset = set(cells)
        for dx, dy in cells:
            if (dx - 1, dy) not in cellset and (dx, dy - 1) not in cellset:
                c = pal["L"]
            elif (dx + 1, dy) not in cellset and (dx, dy + 1) not in cellset:
                c = pal["D"]
            else:
                c = pal["M"]
            put(px, 16, 16, ox + dx, oy + dy, c)
    return img


# ----------------------------------------------------------------------------- ingot / dust / hammer
def make_ingot(pal):
    img = new_img()
    px = img.load()
    shape = {}
    for i in range(4):                      # top face (parallelogram, 9 wide)
        y = 4 + i
        x0 = 4 - i
        for x in range(x0, x0 + 9):
            shape[(x, y)] = "T0" if i == 0 else ("TL" if x - x0 <= 1 else "T")
        for x in (x0 + 9, x0 + 10):         # right end face, follows the slant
            shape[(x, y)] = "S2" if i % 2 == 0 else "S"
    for y in range(8, 12):                  # front face (4 rows)
        for x in range(1, 10):
            shape[(x, y)] = "FD" if y == 11 else ("FL" if y == 8 else "F")
        for x in (10, 11):
            shape[(x, y)] = "S"
    colors = {"T0": pal["L"], "TL": pal["L"], "T": pal["M"], "F": pal["M"], "FL": pal["L"],
              "FD": pal["D"], "S": pal["D"], "S2": pal["M"]}
    for (x, y), k in shape.items():
        put(px, 16, 16, x, y + 1, colors[k])
    # outline
    outline = set()
    for (x, y) in shape:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            if (x + dx, y + dy) not in shape:
                outline.add((x + dx, y + dy))
    for (x, y) in outline:
        put(px, 16, 16, x, y + 1, pal["O"])
    return img


DUST_SHAPE = [
    "................",
    "................",
    "................",
    "................",
    "................",
    ".......HH.......",
    "......HMMM......",
    ".....HMMMMM.....",
    "....HMMMMMMS....",
    "...HMMMMMMMMS...",
    "..HMMMMMMMMMMS..",
    ".HMMMMMMMMMMMMS.",
    ".MMMMMMMMMMMMSS.",
    "..SSSSSSSSSSSS..",
    "................",
    "................",
]


def make_dust(pal, seed):
    rnd = random.Random(seed)
    img = new_img()
    px = img.load()
    for y, row in enumerate(DUST_SHAPE):
        for x, ch in enumerate(row):
            if ch == ".":
                continue
            c = {"H": pal["L"], "M": pal["M"], "S": pal["D"]}[ch]
            if ch == "M":
                r = rnd.random()
                if r < 0.16:
                    c = pal["L"]
                elif r < 0.30:
                    c = pal["D"]
            put(px, 16, 16, x, y, c)
    return img


def make_hammer():
    img = new_img()
    px = img.load()
    wood_l, wood_m, wood_d = (190, 138, 72), (150, 100, 50), (98, 62, 28)
    iron_l, iron_m, iron_d, iron_o = (226, 228, 234), (176, 180, 190), (112, 116, 128), (44, 46, 56)
    # handle: from bottom-left up to the head
    for i in range(8):
        x, y = 2 + i, 14 - i
        put(px, 16, 16, x, y, wood_l)
        put(px, 16, 16, x + 1, y, wood_m)
        put(px, 16, 16, x + 1, y + 1, wood_d)
        put(px, 16, 16, x + 2, y + 1, wood_d)
    put(px, 16, 16, 1, 15, wood_d)
    put(px, 16, 16, 2, 15, wood_d)
    # head: 8x6 block with outline
    x0, y0, x1, y1 = 7, 1, 14, 6
    for x in range(x0, x1 + 1):
        for y in range(y0, y1 + 1):
            if x in (x0, x1) or y in (y0, y1):
                c = iron_o
            elif y == y0 + 1 or x == x0 + 1:
                c = iron_l
            elif y == y1 - 1 or x == x1 - 1:
                c = iron_d
            else:
                c = iron_m
            put(px, 16, 16, x, y, c)
    return img


# ----------------------------------------------------------------------------- storage block
def make_block(pal, seed):
    rnd = random.Random(seed)
    img = new_img()
    px = img.load()
    for y in range(16):
        for x in range(16):
            r = rnd.random()
            c = pal["L"] if r < 0.10 else (pal["D"] if r < 0.20 else pal["M"])
            px[x, y] = rgba(c)
    for i in range(16):                                   # outer dark frame
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            px[x, y] = rgba(pal["O"])
    for i in range(1, 15):                                # bevel
        px[i, 1] = rgba(pal["L"])
        px[1, i] = rgba(pal["L"])
        px[i, 14] = rgba(pal["D"])
        px[14, i] = rgba(pal["D"])
    for (x, y) in ((3, 3), (12, 3), (3, 12), (12, 12)):   # rivets
        px[x, y] = rgba(pal["L"])
        px[x + 1, y + 1] = rgba(pal["D"]) if x + 1 < 15 and y + 1 < 15 else px[x, y]
    return img


# ----------------------------------------------------------------------------- machine
STEEL = dict(base=(108, 110, 118), light=(148, 150, 160), dark=(76, 78, 88), edge=(46, 48, 56))


def steel_plate(seed):
    rnd = random.Random(seed)
    img = new_img()
    px = img.load()
    for y in range(16):
        for x in range(16):
            r = rnd.random()
            c = STEEL["light"] if r < 0.08 else (STEEL["dark"] if r < 0.20 else STEEL["base"])
            px[x, y] = rgba(c)
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            px[x, y] = rgba(STEEL["edge"])
    for i in range(1, 15):
        px[i, 1] = rgba(STEEL["light"])
        px[1, i] = rgba(STEEL["light"])
        px[i, 14] = rgba(STEEL["dark"])
        px[14, i] = rgba(STEEL["dark"])
    for (x, y) in ((2, 2), (13, 2), (2, 13), (13, 13)):   # rivets
        px[x, y] = rgba((176, 178, 188))
    return img


def machine_side():
    img = steel_plate(11)
    px = img.load()
    for y in (5, 7, 9):                                    # vents
        for x in range(5, 11):
            px[x, y] = rgba((40, 42, 50))
        for x in range(5, 11):
            px[x, y + 1] = rgba(STEEL["light"]) if y + 1 < 14 else px[x, y + 1]
    return img


def machine_top():
    img = steel_plate(12)
    px = img.load()
    for x in range(3, 13):
        for y in range(3, 13):
            px[x, y] = rgba(STEEL["edge"])                 # hopper frame
    for y in range(4, 12):
        for x in range(4, 12):
            px[x, y] = rgba((22, 22, 28) if y % 2 == 0 else (70, 72, 82))
    return img


def machine_front(active):
    img = steel_plate(13)
    px = img.load()
    # window frame
    for x in range(2, 14):
        for y in range(2, 11):
            px[x, y] = rgba((30, 30, 36))
    # window interior
    for y in range(3, 10):
        for x in range(3, 13):
            if active:
                t = (y - 3) / 6.0
                c = (255, int(210 - 70 * t), int(90 - 50 * t))
            else:
                c = (22, 22, 28)
            px[x, y] = rgba(c)
    # grinding rollers with teeth
    for rx in (4, 9):
        for y in range(4, 9):
            tooth = (y % 2 == 0)
            body = (150, 152, 160) if tooth else (92, 94, 104)
            dark = (100, 102, 112) if tooth else (62, 64, 72)
            if active:
                body = (int(body[0] * 0.8 + 50), int(body[1] * 0.6 + 30), int(body[2] * 0.4))
                dark = (int(dark[0] * 0.8 + 30), int(dark[1] * 0.5 + 20), int(dark[2] * 0.3))
            px[rx, y] = rgba(body)
            px[rx + 1, y] = rgba(body)
            px[rx + 2, y] = rgba(dark)
    # fuel door
    for x in range(4, 12):
        px[x, 11] = rgba(STEEL["light"])
        for y in (12, 13):
            if active:
                px[x, y] = rgba((255, 190, 60) if y == 12 else (230, 120, 30))
            else:
                px[x, y] = rgba((26, 26, 32))
    return img


# ----------------------------------------------------------------------------- GUI
def draw_rect(px, x0, y0, x1, y1, c):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px[x, y] = rgba(c)


def draw_slot(px, x, y):
    """Vanilla-style 18x18 slot whose item origin is (x, y)."""
    x0, y0 = x - 1, y - 1
    draw_rect(px, x0, y0, x0 + 17, y0 + 17, (139, 139, 139))
    for i in range(18):
        px[x0 + i, y0] = rgba((55, 55, 55))
        px[x0, y0 + i] = rgba((55, 55, 55))
        px[x0 + i, y0 + 17] = rgba((255, 255, 255))
        px[x0 + 17, y0 + i] = rgba((255, 255, 255))
    px[x0 + 17, y0] = rgba((139, 139, 139))
    px[x0, y0 + 17] = rgba((139, 139, 139))


FLAME_ROWS = [
    "......#.......",
    "......##......",
    ".....###......",
    ".....####.....",
    "....#####.#...",
    "...######.##..",
    "...#########..",
    "..###########.",
    "..###########.",
    ".#############",
    ".#############",
    ".#############",
    "..###########.",
    "...#########..",
]


def draw_flame(px, ox, oy, lit):
    for y, row in enumerate(FLAME_ROWS):
        for x, ch in enumerate(row):
            if ch != "#":
                continue
            if lit:
                t = y / 13.0
                core = 3 <= x <= 9 and y >= 6
                c = (255, int(236 - 130 * t), int(100 - 90 * t)) if not core else (255, 240, 170 - int(90 * t))
            else:
                c = (92, 92, 92)
            px[ox + x, oy + y] = rgba(c)


def draw_arrow(px, ox, oy, lit):
    outline = (255, 140, 30) if lit else (80, 80, 80)
    fill = (255, 196, 80) if lit else (160, 160, 160)

    def mark(x, y, c):
        px[ox + x, oy + y] = rgba(c)

    cells = set()
    for x in range(0, 16):
        for y in range(6, 11):
            cells.add((x, y))
    for dx in range(8):
        hh = 8 - dx
        for y in range(8 - hh, 8 + hh + 1):
            cells.add((16 + dx, y))
    for (x, y) in cells:
        edge = any((x + a, y + b) not in cells for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        mark(x, y, outline if edge else fill)


def make_gui():
    img = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    px = img.load()
    # panel
    draw_rect(px, 0, 0, 175, 165, (198, 198, 198))
    for i in range(176):
        px[i, 0] = rgba((0, 0, 0))
        px[i, 165] = rgba((0, 0, 0))
        px[i, 1] = rgba((255, 255, 255)) if 1 < i < 174 else px[i, 1]
        px[i, 164] = rgba((85, 85, 85)) if 1 < i < 174 else px[i, 164]
    for j in range(166):
        px[0, j] = rgba((0, 0, 0))
        px[175, j] = rgba((0, 0, 0))
        px[1, j] = rgba((255, 255, 255)) if 1 < j < 164 else px[1, j]
        px[174, j] = rgba((85, 85, 85)) if 1 < j < 164 else px[174, j]
    for (x, y) in ((0, 0), (175, 0), (0, 165), (175, 165)):
        px[x, y] = rgba((0, 0, 0, 0))
    # machine slots
    for (x, y) in ((56, 17), (56, 53), (110, 35), (138, 35)):
        draw_slot(px, x, y)
    # player inventory + hotbar
    for row in range(3):
        for col in range(9):
            draw_slot(px, 8 + col * 18, 84 + row * 18)
    for col in range(9):
        draw_slot(px, 8 + col * 18, 142)
    # empty flame and arrow silhouettes inside the panel
    draw_flame(px, 56, 36, False)
    draw_arrow(px, 79, 34, False)
    # animated sprites (right of the panel)
    draw_flame(px, 176, 0, True)
    draw_arrow(px, 176, 14, True)
    return img


# ----------------------------------------------------------------------------- json assets
def cube_model(texture):
    return {"parent": "block/cube_all", "textures": {"all": "%s:blocks/%s" % (MODID, texture)}}


def item_model(texture, parent="item/generated"):
    return {"parent": parent, "textures": {"layer0": "%s:items/%s" % (MODID, texture)}}


def ore_dict(name):
    return {"type": "forge:ore_dict", "ore": name}


def gen_models():
    for block in ("copper_ore", "tin_ore", "copper_block", "tin_block"):
        save_json({"forge_marker": 1, "variants": {"normal": {"model": "%s:%s" % (MODID, block)}}}, "blockstates", block + ".json")
        save_json(cube_model(block), "models", "block", block + ".json")
        save_json({"parent": "%s:block/%s" % (MODID, block)}, "models", "item", block + ".json")

    # pulverizer: orientable (front = north) in two states, rotated for each facing
    save_json({"parent": "block/orientable", "textures": {
        "top": "%s:blocks/pulverizer_top" % MODID,
        "front": "%s:blocks/pulverizer_front" % MODID,
        "side": "%s:blocks/pulverizer_side" % MODID}}, "models", "block", "pulverizer.json")
    save_json({"parent": "block/orientable", "textures": {
        "top": "%s:blocks/pulverizer_top" % MODID,
        "front": "%s:blocks/pulverizer_front_on" % MODID,
        "side": "%s:blocks/pulverizer_side" % MODID}}, "models", "block", "pulverizer_on.json")
    save_json({"parent": "%s:block/pulverizer" % MODID}, "models", "item", "pulverizer.json")
    variants = {}
    for facing, rot in (("north", 0), ("east", 90), ("south", 180), ("west", 270)):
        for active in ("false", "true"):
            model = "%s:pulverizer%s" % (MODID, "_on" if active == "true" else "")
            entry = {"model": model}
            if rot:
                entry["y"] = rot
            variants["facing=%s,active=%s" % (facing, active)] = entry
    save_json({"variants": variants}, "blockstates", "pulverizer.json")

    for item in ("ingot_copper", "ingot_tin", "dust_copper", "dust_tin", "dust_iron", "dust_gold"):
        save_json(item_model(item), "models", "item", item + ".json")
    save_json(item_model("hammer", "item/handheld"), "models", "item", "hammer.json")


def gen_recipes():
    def recipe(name, obj):
        save_json(obj, "recipes", name + ".json")

    item = lambda n, **kw: dict({"item": n}, **kw)

    recipe("hammer", {
        "type": "minecraft:crafting_shaped",
        "pattern": ["II ", "IS ", " S "],
        "key": {"I": item("minecraft:iron_ingot"), "S": item("minecraft:stick")},
        "result": item("%s:hammer" % MODID)})

    recipe("pulverizer", {
        "type": "minecraft:crafting_shaped",
        "pattern": ["FFF", "IKI", "IPI"],
        "key": {"F": item("minecraft:flint"), "I": item("minecraft:iron_ingot"),
                "K": item("minecraft:furnace"), "P": item("minecraft:piston")},
        "result": item("%s:pulverizer" % MODID)})

    for metal, ore, dust in (("copper", "oreCopper", "dust_copper"), ("tin", "oreTin", "dust_tin"),
                             ("iron", "oreIron", "dust_iron"), ("gold", "oreGold", "dust_gold")):
        recipe("hammer_%s_ore" % metal, {
            "type": "minecraft:crafting_shapeless",
            "ingredients": [item("%s:hammer" % MODID, data=32767), ore_dict(ore)],
            "result": item("%s:%s" % (MODID, dust))})

    for metal in ("copper", "tin"):
        cap = metal.capitalize()
        recipe("%s_block" % metal, {
            "type": "minecraft:crafting_shaped",
            "pattern": ["III", "III", "III"],
            "key": {"I": ore_dict("ingot" + cap)},
            "result": item("%s:%s_block" % (MODID, metal))})
        recipe("%s_ingot_from_block" % metal, {
            "type": "minecraft:crafting_shapeless",
            "ingredients": [item("%s:%s_block" % (MODID, metal))],
            "result": item("%s:ingot_%s" % (MODID, metal), count=9)})


EN = {
    "itemGroup.industria": "Industria",
    "container.industria.pulverizer": "Pulverizer",
    "tile.industria.copper_ore.name": "Copper Ore",
    "tile.industria.tin_ore.name": "Tin Ore",
    "tile.industria.copper_block.name": "Block of Copper",
    "tile.industria.tin_block.name": "Block of Tin",
    "tile.industria.pulverizer.name": "Pulverizer",
    "item.industria.ingot_copper.name": "Copper Ingot",
    "item.industria.ingot_tin.name": "Tin Ingot",
    "item.industria.dust_copper.name": "Copper Dust",
    "item.industria.dust_tin.name": "Tin Dust",
    "item.industria.dust_iron.name": "Iron Dust",
    "item.industria.dust_gold.name": "Gold Dust",
    "item.industria.hammer.name": "Hammer",
}
RU = {
    "itemGroup.industria": "Industria",
    "container.industria.pulverizer": "Дробилка",
    "tile.industria.copper_ore.name": "Медная руда",
    "tile.industria.tin_ore.name": "Оловянная руда",
    "tile.industria.copper_block.name": "Медный блок",
    "tile.industria.tin_block.name": "Оловянный блок",
    "tile.industria.pulverizer.name": "Дробилка",
    "item.industria.ingot_copper.name": "Медный слиток",
    "item.industria.ingot_tin.name": "Оловянный слиток",
    "item.industria.dust_copper.name": "Медная пыль",
    "item.industria.dust_tin.name": "Оловянная пыль",
    "item.industria.dust_iron.name": "Железная пыль",
    "item.industria.dust_gold.name": "Золотая пыль",
    "item.industria.hammer.name": "Молот",
}


def gen_lang():
    for code, table in (("en_us", EN), ("ru_ru", RU)):
        save_text("".join("%s=%s\n" % (k, v) for k, v in table.items()), "lang", code + ".lang")


def gen_meta():
    with open(os.path.join(RES, "pack.mcmeta"), "w", encoding="utf-8") as fh:
        json.dump({"pack": {"description": "Industria resources", "pack_format": 3}}, fh, indent=2)
        fh.write("\n")
    with open(os.path.join(RES, "mcmod.info"), "w", encoding="utf-8") as fh:
        json.dump([{
            "modid": MODID, "name": "Industria", "description": "Industrial mod: ores, dusts and machines.",
            "version": "0.1.0", "mcversion": "1.12.2", "authorList": [], "credits": "", "url": "",
            "screenshots": [], "dependencies": []}], fh, indent=2)
        fh.write("\n")


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stone", help="path to vanilla 16x16 stone.png to use as the ore base")
    args = ap.parse_args()

    stone = stone_base(args.stone)
    for metal, pal in METALS.items():
        save_png(make_ore(stone, pal), "textures", "blocks", "%s_ore.png" % metal)
        save_png(make_ingot(pal), "textures", "items", "ingot_%s.png" % metal)
        save_png(make_block(pal, 100 + len(metal)), "textures", "blocks", "%s_block.png" % metal)
    for i, (metal, pal) in enumerate(DUSTS.items()):
        save_png(make_dust(pal, 500 + i), "textures", "items", "dust_%s.png" % metal)
    save_png(make_hammer(), "textures", "items", "hammer.png")

    save_png(machine_side(), "textures", "blocks", "pulverizer_side.png")
    save_png(machine_top(), "textures", "blocks", "pulverizer_top.png")
    save_png(machine_front(False), "textures", "blocks", "pulverizer_front.png")
    save_png(machine_front(True), "textures", "blocks", "pulverizer_front_on.png")
    save_png(make_gui(), "textures", "gui", "pulverizer.png")

    gen_models()
    gen_recipes()
    gen_lang()
    gen_meta()
    print("Assets written to", ASSETS)


if __name__ == "__main__":
    main()
