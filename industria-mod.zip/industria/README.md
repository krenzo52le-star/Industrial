# Industria — индустриальный мод для Minecraft 1.12.2 (Forge)

Этап 1: руды, слитки, пыль, молот и дробилка на топливе.

## Что есть в моде

| Что | Детали |
|---|---|
| Руды | Медная (Y 20–64) и оловянная (Y 10–48), генерация в Верхнем мире, нужна каменная кирка |
| Слитки | Медный, оловянный. Плавятся из руды и пыли в обычной печи |
| Пыль | Медная, оловянная, железная, золотая |
| Блоки металла | Медный и оловянный блоки (9 слитков), обратно в 9 слитков |
| Молот | 128 использований, остаётся в верстаке: молот + руда → 1 пыль |
| Дробилка | Работает на топливе (как печь), 2 пыли из руды, шанс на побочную пыль, принимает предметы из воронок |
| Вкладка | «Industria» в творческом режиме |

Рецепты дробилки: руда → 2 пыли (+шанс бонуса), слиток → пыль, булыжник → гравий (+кремень),
гравий → песок, песчаник → 2 песка, кость → 6 костной муки, огненный стержень → 4 огненного порошка.

Крафт дробилки: 3 кремня сверху, 4 железных слитка по бокам, печь и поршень в центре.

## Как собрать

### Способ 1 (самый надёжный): через официальный Forge MDK
1. Установи **JDK 8**.
2. Скачай **Forge MDK 1.12.2** (14.23.5.2860) с files.minecraftforge.net и распакуй.
3. Удали из MDK папку `src` и скопируй сюда `src` из этого проекта.
4. В `build.gradle` MDK поставь `group = "com.industria"`, `archivesBaseName = "industria"`, `version = "0.1.0"`.
5. В папке MDK выполни: `gradlew setupDecompWorkspace` (долго, один раз), затем `gradlew build`.
   Готовый мод: `build/libs/industria-0.1.0.jar`. Положи его в `mods`.
6. Для теста в самой разработке: `gradlew runClient`.

### Способ 2: этот проект напрямую
Нужен Gradle 4.9 и JDK 8: `gradle setupDecompWorkspace`, затем `gradle build`.
ForgeGradle 2.3 капризен в новых системах, если не заведётся, используй способ 1.

## Структура

```
src/main/java/com/industria/
  Industria.java            главный класс мода, вкладка креатива
  Reference.java            modid, версия
  init/                     ModBlocks, ModItems, ModRecipes (oredict, плавка)
  handler/                  регистрация блоков/предметов/моделей
  block/                    BlockBasic (руды, блоки), BlockPulverizer
  item/ItemHammer.java
  tile/TilePulverizer.java  логика машины: топливо, прогресс, слоты
  container/                ContainerPulverizer (слоты, шифт-клик, синхронизация)
  client/gui/               GuiPulverizer (отрисовка)
  gui/GuiHandler.java       открытие GUI
  recipe/PulverizerRecipes  рецепты дробилки
  world/OreGenerator.java   генерация руд
src/main/resources/assets/industria/   текстуры, модели, blockstates, рецепты, lang
tools/generate_assets.py   рисует все текстуры и создаёт JSON-файлы
```

## Текстуры

Все текстуры нарисованы скриптом `tools/generate_assets.py` (нужен `pip install pillow`),
16×16 в стиле Майнкрафта. Основа для руд: если положить ванильный `stone.png`
(из `assets/minecraft/textures/blocks/` в `.minecraft/versions/1.12.2/1.12.2.jar`),
руды перекрасятся поверх настоящего камня:

```
python3 tools/generate_assets.py --stone путь/к/stone.png
```

## Как добавить рецепт дробилки (в коде)

```java
// в PulverizerRecipes.init()
addOreRecipe("oreLead", new ItemStack(ModItems.DUST_LEAD, 2), ItemStack.EMPTY, 0, ORE_TIME);
```

## Следующие этапы

Этап 2: энергия (Forge Energy), генератор, провода, перевод дробилки с топлива на энергию.
Этап 3: трубы и конвейеры, накопители, апгрейды. Этап 4: жидкости и мультиблоки.
