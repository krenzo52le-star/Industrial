package com.industria;

public final class Reference {
    public static final String MOD_ID = "industria";
    public static final String MOD_NAME = "Industria";
    public static final String VERSION = "0.1.0";

    public static final String CLIENT_PROXY = "com.industria.proxy.ClientProxy";
    public static final String COMMON_PROXY = "com.industria.proxy.CommonProxy";

    private Reference() {
    }
}
