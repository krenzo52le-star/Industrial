package com.industria.tile;

import com.industria.block.BlockPulverizer;
import com.industria.init.ModBlocks;
import com.industria.recipe.PulverizerRecipes;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Pulverizer (stage 1): burns fuel like a furnace and grinds one input item into dust.
 * Later stages can replace the fuel with an energy buffer; the process loop stays the same.
 */
public class TilePulverizer extends TileEntity implements ITickable {

    public static final int SLOT_INPUT = 0;
    public static final int SLOT_FUEL = 1;
    public static final int SLOT_OUTPUT = 2;
    public static final int SLOT_BYPRODUCT = 3;

    public static final int FIELD_BURN_TIME = 0;
    public static final int FIELD_CURRENT_BURN_TIME = 1;
    public static final int FIELD_PROGRESS = 2;
    public static final int FIELD_TOTAL_TIME = 3;
    public static final int FIELD_COUNT = 4;

    private final ItemStackHandler inventory = new ItemStackHandler(4) {
        @Override
        protected void onContentsChanged(int slot) {
            TilePulverizer.this.markDirty();
        }
    };

    /** What hoppers and pipes see: input/fuel can be inserted, outputs can be extracted. */
    private final ItemStackHandler automation = new AutomationView();

    private int burnTime;
    private int currentBurnTime;
    private int progress;
    private int totalTime;

    public ItemStackHandler getInventory() {
        return inventory;
    }

    public boolean isBurning() {
        return burnTime > 0;
    }

    // ------------------------------------------------------------------ logic

    @Override
    public void update() {
        if (world == null || world.isRemote) {
            return;
        }

        boolean wasBurning = burnTime > 0;
        boolean changed = false;

        if (burnTime > 0) {
            burnTime--;
            changed = true;
        }

        PulverizerRecipes.Recipe recipe = PulverizerRecipes.find(inventory.getStackInSlot(SLOT_INPUT));
        if (recipe != null && canOutput(recipe)) {
            if (burnTime == 0 && tryConsumeFuel()) {
                changed = true;
            }
            if (burnTime > 0) {
                totalTime = recipe.getTime();
                progress++;
                changed = true;
                if (progress >= totalTime) {
                    progress = 0;
                    craft(recipe);
                }
            } else if (progress > 0) {
                progress = Math.max(0, progress - 2);
                changed = true;
            }
        } else if (progress > 0) {
            progress = 0;
            changed = true;
        }

        boolean burning = burnTime > 0;
        if (wasBurning != burning) {
            setActive(burning);
            changed = true;
        }

        if (changed) {
            markDirty();
        }
    }

    private boolean tryConsumeFuel() {
        ItemStack fuel = inventory.getStackInSlot(SLOT_FUEL);
        if (fuel.isEmpty()) {
            return false;
        }
        int time = TileEntityFurnace.getItemBurnTime(fuel);
        if (time <= 0) {
            return false;
        }
        burnTime = time;
        currentBurnTime = time;
        if (fuel.getItem().hasContainerItem(fuel)) {
            // e.g. a lava bucket leaves an empty bucket behind
            inventory.setStackInSlot(SLOT_FUEL, fuel.getItem().getContainerItem(fuel));
        } else {
            fuel.shrink(1);
        }
        return true;
    }

    private boolean canOutput(PulverizerRecipes.Recipe recipe) {
        ItemStack current = inventory.getStackInSlot(SLOT_OUTPUT);
        ItemStack result = recipe.getOutput();
        if (current.isEmpty()) {
            return true;
        }
        if (!current.isItemEqual(result) || !ItemStack.areItemStackTagsEqual(current, result)) {
            return false;
        }
        int limit = Math.min(inventory.getSlotLimit(SLOT_OUTPUT), current.getMaxStackSize());
        return current.getCount() + result.getCount() <= limit;
    }

    private void craft(PulverizerRecipes.Recipe recipe) {
        ItemStack result = recipe.getOutput();
        ItemStack current = inventory.getStackInSlot(SLOT_OUTPUT);
        if (current.isEmpty()) {
            inventory.setStackInSlot(SLOT_OUTPUT, result);
        } else {
            current.grow(result.getCount());
        }

        ItemStack bonus = recipe.getByproduct();
        if (!bonus.isEmpty() && recipe.getChance() > 0 && world.rand.nextInt(100) < recipe.getChance()) {
            // if the byproduct slot is full the bonus is simply lost
            inventory.insertItem(SLOT_BYPRODUCT, bonus, false);
        }

        inventory.getStackInSlot(SLOT_INPUT).shrink(1);
    }

    private void setActive(boolean active) {
        IBlockState state = world.getBlockState(pos);
        if (state.getBlock() == ModBlocks.PULVERIZER && state.getValue(BlockPulverizer.ACTIVE) != active) {
            world.setBlockState(pos, state.withProperty(BlockPulverizer.ACTIVE, active), 3);
        }
    }

    // ------------------------------------------------------------ GUI helpers

    public int getField(int id) {
        switch (id) {
            case FIELD_BURN_TIME:
                return burnTime;
            case FIELD_CURRENT_BURN_TIME:
                return currentBurnTime;
            case FIELD_PROGRESS:
                return progress;
            case FIELD_TOTAL_TIME:
                return totalTime;
            default:
                return 0;
        }
    }

    public void setField(int id, int value) {
        switch (id) {
            case FIELD_BURN_TIME:
                burnTime = value;
                break;
            case FIELD_CURRENT_BURN_TIME:
                currentBurnTime = value;
                break;
            case FIELD_PROGRESS:
                progress = value;
                break;
            case FIELD_TOTAL_TIME:
                totalTime = value;
                break;
            default:
                break;
        }
    }

    /** Remaining flame height in pixels (0..pixels). */
    public int getBurnScaled(int pixels) {
        int max = currentBurnTime == 0 ? 200 : currentBurnTime;
        return Math.min(pixels, burnTime * pixels / max);
    }

    /** Arrow progress in pixels (0..pixels). */
    public int getProgressScaled(int pixels) {
        return totalTime != 0 && progress != 0 ? Math.min(pixels, progress * pixels / totalTime) : 0;
    }

    // ------------------------------------------------------------------- NBT

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        inventory.deserializeNBT(compound.getCompoundTag("Inventory"));
        burnTime = compound.getInteger("BurnTime");
        currentBurnTime = compound.getInteger("CurrentBurnTime");
        progress = compound.getInteger("Progress");
        totalTime = compound.getInteger("TotalTime");
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setTag("Inventory", inventory.serializeNBT());
        compound.setInteger("BurnTime", burnTime);
        compound.setInteger("CurrentBurnTime", currentBurnTime);
        compound.setInteger("Progress", progress);
        compound.setInteger("TotalTime", totalTime);
        return compound;
    }

    // ------------------------------------------------------------ capability

    @Override
    public boolean hasCapability(@Nonnull Capability<?> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability(capability, facing);
    }

    @Nullable
    @Override
    public <T> T getCapability(@Nonnull Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(automation);
        }
        return super.getCapability(capability, facing);
    }

    /** Restricted view of the inventory for automation. */
    private class AutomationView extends ItemStackHandler {

        AutomationView() {
            super(4);
        }

        @Override
        public int getSlots() {
            return inventory.getSlots();
        }

        @Nonnull
        @Override
        public ItemStack getStackInSlot(int slot) {
            return inventory.getStackInSlot(slot);
        }

        @Nonnull
        @Override
        public ItemStack insertItem(int slot, @Nonnull ItemStack stack, boolean simulate) {
            if (slot == SLOT_INPUT && PulverizerRecipes.hasRecipe(stack)) {
                return inventory.insertItem(slot, stack, simulate);
            }
            if (slot == SLOT_FUEL && TileEntityFurnace.isItemFuel(stack)) {
                return inventory.insertItem(slot, stack, simulate);
            }
            return stack;
        }

        @Nonnull
        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            if (slot == SLOT_OUTPUT || slot == SLOT_BYPRODUCT) {
                return inventory.extractItem(slot, amount, simulate);
            }
            return ItemStack.EMPTY;
        }

        @Override
        public int getSlotLimit(int slot) {
            return inventory.getSlotLimit(slot);
        }
    }
}
