package com.industria.recipe;

import com.industria.init.ModItems;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Pulverizer recipe registry. One input item -> one output (+ optional chance byproduct).
 * An input is either an ore dictionary name or a concrete item stack.
 */
public final class PulverizerRecipes {

    public static final int ORE_TIME = 160;
    public static final int INGOT_TIME = 100;

    private static final List<Recipe> RECIPES = new ArrayList<>();

    public static void init() {
        RECIPES.clear();

        // Ores: two dusts + a small chance of a bonus dust
        addOreRecipe("oreCopper", stack(ModItems.DUST_COPPER, 2), stack(ModItems.DUST_GOLD, 1), 8, ORE_TIME);
        addOreRecipe("oreTin", stack(ModItems.DUST_TIN, 2), stack(ModItems.DUST_IRON, 1), 10, ORE_TIME);
        addOreRecipe("oreIron", stack(ModItems.DUST_IRON, 2), stack(ModItems.DUST_TIN, 1), 10, ORE_TIME);
        addOreRecipe("oreGold", stack(ModItems.DUST_GOLD, 2), stack(ModItems.DUST_COPPER, 1), 10, ORE_TIME);

        // Ingots -> dust (to re-melt or to clean up)
        addOreRecipe("ingotCopper", stack(ModItems.DUST_COPPER, 1), ItemStack.EMPTY, 0, INGOT_TIME);
        addOreRecipe("ingotTin", stack(ModItems.DUST_TIN, 1), ItemStack.EMPTY, 0, INGOT_TIME);
        addOreRecipe("ingotIron", stack(ModItems.DUST_IRON, 1), ItemStack.EMPTY, 0, INGOT_TIME);
        addOreRecipe("ingotGold", stack(ModItems.DUST_GOLD, 1), ItemStack.EMPTY, 0, INGOT_TIME);

        // Vanilla conveniences
        addItemRecipe(new ItemStack(Blocks.COBBLESTONE), new ItemStack(Blocks.GRAVEL), new ItemStack(Items.FLINT), 10, INGOT_TIME);
        addItemRecipe(new ItemStack(Blocks.GRAVEL), new ItemStack(Blocks.SAND), ItemStack.EMPTY, 0, INGOT_TIME);
        addItemRecipe(new ItemStack(Blocks.SANDSTONE, 1, OreDictionary.WILDCARD_VALUE), new ItemStack(Blocks.SAND, 2), ItemStack.EMPTY, 0, INGOT_TIME);
        addItemRecipe(new ItemStack(Items.BONE), new ItemStack(Items.DYE, 6, 15), ItemStack.EMPTY, 0, INGOT_TIME);
        addItemRecipe(new ItemStack(Items.BLAZE_ROD), new ItemStack(Items.BLAZE_POWDER, 4), ItemStack.EMPTY, 0, INGOT_TIME);
    }

    private static ItemStack stack(Item item, int count) {
        return new ItemStack(item, count);
    }

    /** Recipe whose input is an ore dictionary entry. */
    public static Recipe addOreRecipe(String oreName, ItemStack output, ItemStack byproduct, int chance, int time) {
        Recipe recipe = new Recipe(oreName, ItemStack.EMPTY, output, byproduct, chance, time);
        RECIPES.add(recipe);
        return recipe;
    }

    /** Recipe whose input is a concrete item (meta may be OreDictionary.WILDCARD_VALUE). */
    public static Recipe addItemRecipe(ItemStack input, ItemStack output, ItemStack byproduct, int chance, int time) {
        Recipe recipe = new Recipe(null, input, output, byproduct, chance, time);
        RECIPES.add(recipe);
        return recipe;
    }

    /** @return the recipe for the given input, or null if there is none. */
    public static Recipe find(ItemStack input) {
        if (input.isEmpty()) {
            return null;
        }
        for (Recipe recipe : RECIPES) {
            if (recipe.matches(input)) {
                return recipe;
            }
        }
        return null;
    }

    public static boolean hasRecipe(ItemStack input) {
        return find(input) != null;
    }

    public static List<Recipe> getRecipes() {
        return Collections.unmodifiableList(RECIPES);
    }

    private PulverizerRecipes() {
    }

    public static final class Recipe {
        private final String oreName;
        private final ItemStack input;
        private final ItemStack output;
        private final ItemStack byproduct;
        private final int chance;
        private final int time;

        private Recipe(String oreName, ItemStack input, ItemStack output, ItemStack byproduct, int chance, int time) {
            this.oreName = oreName;
            this.input = input;
            this.output = output;
            this.byproduct = byproduct;
            this.chance = chance;
            this.time = time;
        }

        public boolean matches(ItemStack stack) {
            if (stack.isEmpty()) {
                return false;
            }
            if (oreName != null) {
                int id = OreDictionary.getOreID(oreName);
                for (int stackId : OreDictionary.getOreIDs(stack)) {
                    if (stackId == id) {
                        return true;
                    }
                }
                return false;
            }
            return OreDictionary.itemMatches(input, stack, false);
        }

        /** @return a fresh copy of the primary output. */
        public ItemStack getOutput() {
            return output.copy();
        }

        /** @return a fresh copy of the byproduct (may be empty). */
        public ItemStack getByproduct() {
            return byproduct.copy();
        }

        /** Byproduct chance in percent (0-100). */
        public int getChance() {
            return chance;
        }

        /** Processing time in ticks. */
        public int getTime() {
            return time;
        }
    }
}
