package com.industria.world;

import com.industria.init.ModBlocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;

import java.util.Random;

/** Generates copper and tin ore veins in the Overworld. */
public class OreGenerator implements IWorldGenerator {

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.getDimension() != 0) {
            return;
        }
        //                         ore state                           vein size  tries  minY  maxY
        generateOre(ModBlocks.COPPER_ORE.getDefaultState(), world, random, chunkX, chunkZ, 9, 16, 20, 64);
        generateOre(ModBlocks.TIN_ORE.getDefaultState(), world, random, chunkX, chunkZ, 7, 8, 10, 48);
    }

    private void generateOre(IBlockState ore, World world, Random random, int chunkX, int chunkZ,
                             int veinSize, int tries, int minY, int maxY) {
        WorldGenMinable generator = new WorldGenMinable(ore, veinSize);
        for (int i = 0; i < tries; i++) {
            // +8 keeps the vein inside the area that is populated together with this chunk
            int x = chunkX * 16 + 8 + random.nextInt(16);
            int y = minY + random.nextInt(maxY - minY);
            int z = chunkZ * 16 + 8 + random.nextInt(16);
            generator.generate(world, random, new BlockPos(x, y, z));
        }
    }
}
