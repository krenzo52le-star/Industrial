package com.industria.client.gui;

import com.industria.Reference;
import com.industria.container.ContainerPulverizer;
import com.industria.tile.TilePulverizer;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Client-side pulverizer GUI. The texture (256x256) contains the panel at (0,0)
 * and the animated sprites: flame at (176,0) 14x14 and arrow at (176,14) 24x17.
 */
@SideOnly(Side.CLIENT)
public class GuiPulverizer extends GuiContainer {

    private static final ResourceLocation TEXTURE = new ResourceLocation(Reference.MOD_ID, "textures/gui/pulverizer.png");

    private final InventoryPlayer playerInventory;
    private final TilePulverizer tile;

    public GuiPulverizer(InventoryPlayer playerInventory, TilePulverizer tile) {
        super(new ContainerPulverizer(playerInventory, tile));
        this.playerInventory = playerInventory;
        this.tile = tile;
        this.xSize = 176;
        this.ySize = 166;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        super.drawScreen(mouseX, mouseY, partialTicks);
        renderHoveredToolTip(mouseX, mouseY);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        String title = I18n.format("container.industria.pulverizer");
        fontRenderer.drawString(title, xSize / 2 - fontRenderer.getStringWidth(title) / 2, 6, 0x404040);
        fontRenderer.drawString(playerInventory.getDisplayName().getUnformattedText(), 8, ySize - 96 + 2, 0x404040);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        mc.getTextureManager().bindTexture(TEXTURE);
        int x = (width - xSize) / 2;
        int y = (height - ySize) / 2;
        drawTexturedModalRect(x, y, 0, 0, xSize, ySize);

        // flame: grows from the bottom as burn time remains
        if (tile.isBurning()) {
            int h = tile.getBurnScaled(14);
            drawTexturedModalRect(x + 56, y + 36 + 14 - h, 176, 14 - h, 14, h);
        }

        // progress arrow
        int w = tile.getProgressScaled(24);
        drawTexturedModalRect(x + 79, y + 34, 176, 14, w, 17);
    }
}
