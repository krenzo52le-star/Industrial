package com.industria.proxy;

/**
 * Client-only setup. Item/block models are registered in
 * {@link com.industria.handler.ClientRegistryHandler}, so nothing is needed here yet.
 * Future client code (renderers, key bindings) goes here.
 */
public class ClientProxy extends CommonProxy {
}
