package com.industria.block;

import com.industria.Industria;
import com.industria.Reference;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

/** Simple full block: ore or storage block. */
public class BlockBasic extends Block {

    public BlockBasic(String name, Material material, SoundType sound, float hardness, float resistance, int harvestLevel) {
        super(material);
        setRegistryName(Reference.MOD_ID, name);
        setTranslationKey(Reference.MOD_ID + "." + name);
        setHardness(hardness);
        setResistance(resistance);
        setSoundType(sound);
        setHarvestLevel("pickaxe", harvestLevel);
        setCreativeTab(Industria.TAB);
    }
}
