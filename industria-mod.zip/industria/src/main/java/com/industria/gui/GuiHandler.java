package com.industria.gui;

import com.industria.client.gui.GuiPulverizer;
import com.industria.container.ContainerPulverizer;
import com.industria.tile.TilePulverizer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class GuiHandler implements IGuiHandler {

    public static final int PULVERIZER = 0;

    @Override
    public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        TileEntity tile = world.getTileEntity(new BlockPos(x, y, z));
        if (id == PULVERIZER && tile instanceof TilePulverizer) {
            return new ContainerPulverizer(player.inventory, (TilePulverizer) tile);
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        TileEntity tile = world.getTileEntity(new BlockPos(x, y, z));
        if (id == PULVERIZER && tile instanceof TilePulverizer) {
            return new GuiPulverizer(player.inventory, (TilePulverizer) tile);
        }
        return null;
    }
}
