package com.industria.container;

import com.industria.recipe.PulverizerRecipes;
import com.industria.tile.TilePulverizer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

import javax.annotation.Nonnull;

/** Server-side half of the pulverizer GUI: slots, shift-click and progress sync. */
public class ContainerPulverizer extends Container {

    private static final int MACHINE_SLOTS = 4;                    // 0..3
    private static final int PLAYER_INV_START = MACHINE_SLOTS;     // 4..30
    private static final int HOTBAR_START = PLAYER_INV_START + 27; // 31..39
    private static final int SLOTS_END = HOTBAR_START + 9;         // 40

    private final TilePulverizer tile;
    private final int[] lastFields = new int[TilePulverizer.FIELD_COUNT];

    public ContainerPulverizer(InventoryPlayer playerInventory, TilePulverizer tile) {
        this.tile = tile;
        IItemHandler inventory = tile.getInventory();

        addSlotToContainer(new SlotItemHandler(inventory, TilePulverizer.SLOT_INPUT, 56, 17) {
            @Override
            public boolean isItemValid(@Nonnull ItemStack stack) {
                return PulverizerRecipes.hasRecipe(stack);
            }
        });
        addSlotToContainer(new SlotItemHandler(inventory, TilePulverizer.SLOT_FUEL, 56, 53) {
            @Override
            public boolean isItemValid(@Nonnull ItemStack stack) {
                return TileEntityFurnace.isItemFuel(stack);
            }
        });
        addSlotToContainer(new OutputSlot(inventory, TilePulverizer.SLOT_OUTPUT, 110, 35));
        addSlotToContainer(new OutputSlot(inventory, TilePulverizer.SLOT_BYPRODUCT, 138, 35));

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlotToContainer(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlotToContainer(new Slot(playerInventory, col, 8 + col * 18, 142));
        }
    }

    @Override
    public boolean canInteractWith(@Nonnull EntityPlayer player) {
        BlockPos pos = tile.getPos();
        return !tile.isInvalid()
                && player.getDistanceSq(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) <= 64.0D;
    }

    // ------------------------------------------------------- progress syncing

    @Override
    public void detectAndSendChanges() {
        super.detectAndSendChanges();
        for (int id = 0; id < TilePulverizer.FIELD_COUNT; id++) {
            int value = tile.getField(id);
            if (value != lastFields[id]) {
                for (IContainerListener listener : listeners) {
                    listener.sendWindowProperty(this, id, value);
                }
                lastFields[id] = value;
            }
        }
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void updateProgressBar(int id, int data) {
        tile.setField(id, data);
    }

    // ------------------------------------------------------------ shift-click

    @Nonnull
    @Override
    public ItemStack transferStackInSlot(EntityPlayer player, int index) {
        ItemStack original = ItemStack.EMPTY;
        Slot slot = inventorySlots.get(index);
        if (slot != null && slot.getHasStack()) {
            ItemStack stack = slot.getStack();
            original = stack.copy();

            if (index < MACHINE_SLOTS) {
                // machine -> player
                if (!mergeItemStack(stack, PLAYER_INV_START, SLOTS_END, true)) {
                    return ItemStack.EMPTY;
                }
            } else if (PulverizerRecipes.hasRecipe(stack)) {
                if (!mergeItemStack(stack, TilePulverizer.SLOT_INPUT, TilePulverizer.SLOT_INPUT + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (TileEntityFurnace.isItemFuel(stack)) {
                if (!mergeItemStack(stack, TilePulverizer.SLOT_FUEL, TilePulverizer.SLOT_FUEL + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (index < HOTBAR_START) {
                // inventory -> hotbar
                if (!mergeItemStack(stack, HOTBAR_START, SLOTS_END, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (!mergeItemStack(stack, PLAYER_INV_START, HOTBAR_START, false)) {
                // hotbar -> inventory
                return ItemStack.EMPTY;
            }

            if (stack.isEmpty()) {
                slot.putStack(ItemStack.EMPTY);
            } else {
                slot.onSlotChanged();
            }
            if (stack.getCount() == original.getCount()) {
                return ItemStack.EMPTY;
            }
            slot.onTake(player, stack);
        }
        return original;
    }

    /** Slot that only lets the player take items out. */
    private static class OutputSlot extends SlotItemHandler {
        OutputSlot(IItemHandler handler, int index, int x, int y) {
            super(handler, index, x, y);
        }

        @Override
        public boolean isItemValid(@Nonnull ItemStack stack) {
            return false;
        }
    }
}
