package com.industria.item;

import com.industria.Industria;
import com.industria.Reference;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Hammer: stays in the crafting grid and loses durability on every craft. */
public class ItemHammer extends Item {

    public ItemHammer() {
        setRegistryName(Reference.MOD_ID, "hammer");
        setTranslationKey(Reference.MOD_ID + ".hammer");
        setMaxStackSize(1);
        setMaxDamage(128);
        setCreativeTab(Industria.TAB);
    }

    @Override
    public boolean hasContainerItem(ItemStack stack) {
        return true;
    }

    @Override
    public ItemStack getContainerItem(ItemStack stack) {
        ItemStack copy = stack.copy();
        copy.setItemDamage(copy.getItemDamage() + 1);
        if (copy.getItemDamage() > copy.getMaxDamage()) {
            return ItemStack.EMPTY;
        }
        return copy;
    }
}
