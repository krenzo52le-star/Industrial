package com.industria.init;

import com.industria.block.BlockBasic;
import com.industria.block.BlockPulverizer;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

import java.util.ArrayList;
import java.util.List;

public final class ModBlocks {

    /** Every block of the mod; an ItemBlock is created for each of them automatically. */
    public static final List<Block> BLOCKS = new ArrayList<>();

    public static final Block COPPER_ORE = add(new BlockBasic("copper_ore", Material.ROCK, SoundType.STONE, 3.0F, 5.0F, 1));
    public static final Block TIN_ORE = add(new BlockBasic("tin_ore", Material.ROCK, SoundType.STONE, 3.0F, 5.0F, 1));
    public static final Block COPPER_BLOCK = add(new BlockBasic("copper_block", Material.IRON, SoundType.METAL, 5.0F, 10.0F, 1));
    public static final Block TIN_BLOCK = add(new BlockBasic("tin_block", Material.IRON, SoundType.METAL, 5.0F, 10.0F, 1));

    public static final Block PULVERIZER = add(new BlockPulverizer());

    private static Block add(Block block) {
        BLOCKS.add(block);
        return block;
    }

    private ModBlocks() {
    }
}
