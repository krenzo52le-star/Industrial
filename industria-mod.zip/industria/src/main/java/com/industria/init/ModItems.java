package com.industria.init;

import com.industria.Industria;
import com.industria.Reference;
import com.industria.item.ItemHammer;
import net.minecraft.item.Item;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {

    /** Every plain item of the mod (ItemBlocks are created separately). */
    public static final List<Item> ITEMS = new ArrayList<>();

    public static final Item INGOT_COPPER = basic("ingot_copper");
    public static final Item INGOT_TIN = basic("ingot_tin");

    public static final Item DUST_COPPER = basic("dust_copper");
    public static final Item DUST_TIN = basic("dust_tin");
    public static final Item DUST_IRON = basic("dust_iron");
    public static final Item DUST_GOLD = basic("dust_gold");

    public static final Item HAMMER = add(new ItemHammer());

    private static Item basic(String name) {
        Item item = new Item();
        item.setRegistryName(Reference.MOD_ID, name);
        item.setUnlocalizedName(Reference.MOD_ID + "." + name);
        item.setCreativeTab(Industria.TAB);
        return add(item);
    }

    private static Item add(Item item) {
        ITEMS.add(item);
        return item;
    }

    private ModItems() {
    }
}
