package com.industria.init;

import com.industria.recipe.PulverizerRecipes;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.oredict.OreDictionary;

/**
 * Ore dictionary names, furnace recipes and pulverizer recipes.
 * Crafting-table recipes live in JSON: assets/industria/recipes.
 */
public final class ModRecipes {

    public static void init() {
        registerOreDictionary();
        registerSmelting();
        PulverizerRecipes.init();
    }

    private static void registerOreDictionary() {
        OreDictionary.registerOre("oreCopper", ModBlocks.COPPER_ORE);
        OreDictionary.registerOre("oreTin", ModBlocks.TIN_ORE);
        OreDictionary.registerOre("blockCopper", ModBlocks.COPPER_BLOCK);
        OreDictionary.registerOre("blockTin", ModBlocks.TIN_BLOCK);

        OreDictionary.registerOre("ingotCopper", ModItems.INGOT_COPPER);
        OreDictionary.registerOre("ingotTin", ModItems.INGOT_TIN);

        OreDictionary.registerOre("dustCopper", ModItems.DUST_COPPER);
        OreDictionary.registerOre("dustTin", ModItems.DUST_TIN);
        OreDictionary.registerOre("dustIron", ModItems.DUST_IRON);
        OreDictionary.registerOre("dustGold", ModItems.DUST_GOLD);
    }

    private static void registerSmelting() {
        ItemStack copperIngot = new ItemStack(ModItems.INGOT_COPPER);
        ItemStack tinIngot = new ItemStack(ModItems.INGOT_TIN);

        GameRegistry.addSmelting(new ItemStack(ModBlocks.COPPER_ORE), copperIngot.copy(), 0.7F);
        GameRegistry.addSmelting(new ItemStack(ModBlocks.TIN_ORE), tinIngot.copy(), 0.7F);

        GameRegistry.addSmelting(new ItemStack(ModItems.DUST_COPPER), copperIngot.copy(), 0.7F);
        GameRegistry.addSmelting(new ItemStack(ModItems.DUST_TIN), tinIngot.copy(), 0.7F);
        GameRegistry.addSmelting(new ItemStack(ModItems.DUST_IRON), new ItemStack(Items.IRON_INGOT), 0.7F);
        GameRegistry.addSmelting(new ItemStack(ModItems.DUST_GOLD), new ItemStack(Items.GOLD_INGOT), 1.0F);
    }

    private ModRecipes() {
    }
}
